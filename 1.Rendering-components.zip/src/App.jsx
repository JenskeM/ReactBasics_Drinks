import "./App.css";
import { DrinkButton } from "./components/DrinkButtons";

export const App = () => {
  const greeting = "Welcome you all";

  return (
    <div className="app">
      <h1>{greeting}</h1>
      <DrinkButton />
    </div>
  );
};
