import "./DrinkButtons.css";

export const DrinkButton = () => {
  return (
    <>
      <h2>Would you like some tea or do you prefer some coffee?</h2>
      <div className="button-group">
        <button className="button">Tea</button>
        <button className="button">Coffee</button>
      </div>
    </>
  );
};
